package com.nucleus.autowiring;

import org.springframework.stereotype.Component;

@Component("emp")
public class Employee {
	
	public void displayStudent()
	{
		System.out.println("Student..display method in emp");
	}
public void display()
{
	System.out.println("Employee Details...display");
}
}
