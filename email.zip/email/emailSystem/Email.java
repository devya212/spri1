package com.nucleus.emailSystem;

import org.springframework.beans.factory.annotation.Autowired;

public class Email {

	private String Id;
	private String password;
	private Spellchecker spellchecker;
	
	
	

public Spellchecker getSpellchecker() {
		return spellchecker;
	}

	public void setSpellchecker(Spellchecker spellchecker) {
		this.spellchecker = spellchecker;
	}

public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Email [Id=" + Id + ", password=" + password + ", spellchecker=" + spellchecker + "]";
	}

	




	
}
