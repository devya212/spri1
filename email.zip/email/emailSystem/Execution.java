package com.nucleus.emailSystem;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Execution {

	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("email.xml");
		
    	Email e2=(Email) context.getBean("email");
        System.out.println(e2.getId()+" "+e2.getPassword());
Spellchecker s1= e2.getSpellchecker();
       s1.english();
       s1.hindi();
       /* SpellcheckerImpl e3=(SpellcheckerImpl) context.getBean("checker");
        System.out.println(e3);*/
   
	}

}