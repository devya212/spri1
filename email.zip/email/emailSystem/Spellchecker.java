package com.nucleus.emailSystem;


public interface Spellchecker {

	public void english();
	public void hindi();
	
}
