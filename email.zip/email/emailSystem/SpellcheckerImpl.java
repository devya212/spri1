package com.nucleus.emailSystem;

public class SpellcheckerImpl implements Spellchecker{


@Override
	public void english() {
		 
		System.out.println("english spellchecker......");
	}

	@Override
	public void hindi() {
		
		System.out.println("hindi spellchecker......");
	}

}
